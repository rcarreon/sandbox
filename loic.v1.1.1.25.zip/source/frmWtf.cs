﻿using System;
using System.Windows.Forms;

namespace LOIC
{
	public partial class frmWtf : Form
	{
		public frmWtf()
		{
			InitializeComponent();
		}

		private void frmWtf_Click(object sender, EventArgs e)
		{
			this.Dispose();
		}

		private void frmWtf_KeyDown(object sender, KeyEventArgs e)
		{
			this.Dispose();
		}
	}
}
