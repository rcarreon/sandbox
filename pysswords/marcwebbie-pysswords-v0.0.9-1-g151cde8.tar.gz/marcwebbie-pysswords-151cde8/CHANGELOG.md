# Changelog

### 0.0.9

+ **√** Add export/import database
+ **√** Add clean database

### 0.0.8.3

+ **√** Bug fixes for cli

### 0.0.8.2

+ **√** Fix error messages
+ **√** Fix generating keys with GPG1
+ **√** Fix fullname syntax to handle login with (at) signs

### 0.0.8.1

+ **√** Fix finding GPG binaries

### 0.0.8

+ **√** Search with regular expression
+ **√** Bulk update/remove credentials
+ **√** Select credentials by fullname syntax
+ **√** Grouping credentials
